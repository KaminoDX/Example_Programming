<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Rezepte</title>
</head>
<body>
	<nav>
		<ul>
			<li><a href="index.php">Startseite</a></li>
			<li><a href="rezeptview.php">Rezeptübersicht</a></li>
			<li><a href="userrezeptview.php">Rezeptübersicht per User</a></li>
			<li><a href="zutatenrezeptview.php">Zutaten und Rezepte</a></li>
		</ul>
	</nav>
	<h1>Startseite</h1>
	<p>Bitte wählen Sie aus der obigen Navigation.</p>
</body>
</html>